"""SQLite storage."""
